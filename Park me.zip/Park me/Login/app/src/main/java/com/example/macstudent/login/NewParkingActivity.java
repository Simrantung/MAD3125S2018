package com.example.macstudent.login;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import static com.example.macstudent.login.DBHelper.DoB;

public class NewParkingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    Spinner spnCarCompany, spnLot, spnSpot, spnPayment;
    TextView txtAmount, txtDateTime;
    EditText edtCarPlate;
    Button btnAddParking;
    RadioButton rdoOne, rdoTwo, rdoThree, rdoFour;
    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;
    String date,carplate,lot1,spot1,amount;

    int parkingRate[] = {10, 20, 30, 40};
    String lot[] = {"A", "B", "C", "D", "E", "F"};
    String spot[] = {"1", "2", "3", "4", "5"};
    String payment[] = {"Debit Card", "Credit Card", "Master Card", "American Express", "Cash"};
    String carCompany[] = {"BMW", "Audi", "Lexus", "Mercedes", "Jaguar"};
    int logos[] = {R.drawable.img_bmw, R.drawable.img_audi, R.drawable.img_lexus, R.drawable.img_mercedes, R.drawable.img_jaguar};

    String selectedLot, selectedSpot, selectedPayment, selectedCompany;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_parking);

        spnCarCompany = findViewById(R.id.spnCarCompany);
        CarCompanyAdapter carAdapter = new CarCompanyAdapter(getApplicationContext(), logos, carCompany);
        spnCarCompany.setAdapter(carAdapter);
        spnCarCompany.setOnItemSelectedListener(this);


        spnLot = findViewById(R.id.spnLot);
        ArrayAdapter lotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, lot);
        lotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnLot.setAdapter(lotAdapter);
        spnLot.setOnItemSelectedListener(this);


        spnSpot = findViewById(R.id.spnSpot);
        ArrayAdapter spotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, spot);
        spotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnSpot.setAdapter(spotAdapter);
        spnSpot.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnPayment);
        ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, payment);
        paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnPayment.setAdapter(paymentAdapter);
        spnPayment.setOnItemSelectedListener(this);

        txtAmount = findViewById(R.id.txtAmount);
        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        edtCarPlate = findViewById(R.id.edtCarPlate);

        btnAddParking = findViewById(R.id.btnAddParking);
        btnAddParking.setOnClickListener(this);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener(this);

        rdoThree = findViewById(R.id.rdoThree);
        rdoThree.setOnClickListener(this);

        rdoFour = findViewById(R.id.rdoFour);
        rdoFour.setOnClickListener(this);

        dbHelper = new DBHelper(this);
    }

    @Override
    public void onClick(View v) {
        if (rdoOne.isChecked()) {
            txtAmount.setText("$" + parkingRate[0]);
        } else if (rdoTwo.isChecked()) {
            txtAmount.setText("$" + parkingRate[1]);
        } else if (rdoThree.isChecked()) {
            txtAmount.setText("$" + parkingRate[2]);
        } else if (rdoFour.isChecked()) {
            txtAmount.setText("$" + parkingRate[3]);
        }

        if (btnAddParking.getId() == v.getId()) {

            insertData();
            //dbHelper.addData1(date,carplate,lot1,spot1,amount);
        }
    }
        private void insertData() {
            String date = txtDateTime.getText().toString();
            String CarPlate = edtCarPlate.getText().toString();
            String Lot = selectedLot;
            String Spot = selectedSpot;
            String Amount = txtAmount.getText().toString();
//            Toast.makeText(getApplicationContext(), selectedLot,Toast.LENGTH_LONG).show();

            ContentValues cv = new ContentValues();
            cv.put("date",date);
            cv.put("CarPlate",CarPlate);
            cv.put("Lot",Lot);
            cv.put("Spot",Spot);
            cv.put("Amount",Amount);

//            Toast.makeText(getApplicationContext(),cv.toString(),Toast.LENGTH_LONG).show();

            try {
                ParkingDB = dbHelper.getWritableDatabase();
                ParkingDB.insert("ParkingInfo", null, cv);
                Log.v("NewParkingActivity", "Listview");
            } catch (Exception e) {
                Log.e("NewParkingActivity", e.getMessage());
            } finally {

                ParkingDB.close();

            }

            Intent signUpIntent = new Intent(this,ReportActivity.class);
            startActivity(signUpIntent);
        }
           /* SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("CarPlate", edtCarPlate.getText().toString());
            edit.putString("CarCompany", selectedCompany);
            edit.putString("Lot", selectedLot);
            edit.putString("Spot", selectedSpot);
            edit.putString("Payment", selectedPayment);
            edit.putString("DateTime", txtDateTime.getText().toString());
            edit.putInt("Amount", Integer.parseInt(txtAmount.getText().toString().substring(1)));

            edit.commit();

            startActivity(new Intent(getApplicationContext(), ReceiptActivity.class));

            dbHelper.addData1(date,lot1,spot1,amount,carplate);
    }*/

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.getId() == spnLot.getId()) {
            selectedLot = lot[position];
        }else if (parent.getId() == spnSpot.getId()){
            selectedSpot = spot[position];
        }else if (parent.getId() == spnPayment.getId()){
            selectedPayment = payment[position];
        }else if (parent.getId() == spnCarCompany.getId()){
            selectedCompany = carCompany[position];
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}