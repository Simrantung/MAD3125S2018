package com.example.macstudent.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_LONG;

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;
    Cursor cursor;
    int totalReceipts = 0;

    ReportAdapter(Context context){
        this.context=context;
        dbHelper = new DBHelper(this.context);
         try {
            ParkingDB = dbHelper.getReadableDatabase();
            String columns[] = {"date", "CarPlate", "Lot", "Spot", "Amount"};

            cursor = ParkingDB.query("ParkingInfo", columns, null,
                    null, null, null, null);

            this.totalReceipts = cursor.getCount();

//            while(cursor.moveToNext()) {
//                String ParkingData ;
//                ParkingData = cursor.getString(cursor.getColumnIndex("date"));
//                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("CarPlate"));
//                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Lot"));
//                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Spot"));
//                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Amount"));
//
//                Toast.makeText(this.context, ParkingData, LENGTH_LONG).show();
//            }

        }catch (Exception e) {
            Log.e("ReportAdapter", e.getMessage());
        }finally {
//             cursor.moveToFirst();
         }

        inflater = LayoutInflater.from(this.context);


    }
    @Override
    public int getCount() {
        return this.totalReceipts;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        convertView = inflater.inflate(R.layout.list_report_item,null);


        TextView txtDateTime = convertView.findViewById(R.id.txtDateTime);
        TextView txtCarPlate = convertView.findViewById(R.id.txtCarPlate);
        TextView txtAmount = convertView.findViewById(R.id.txtAmount);
        TextView txtLot = convertView.findViewById(R.id.txtLot);
        TextView txtSpot = convertView.findViewById(R.id.txtSpot);

        try{
            cursor.move(position+1);

           //while (cursor.moveToNext()) {

                txtDateTime.setText(cursor.getString(cursor.getColumnIndex("date")));
                txtCarPlate.setText(cursor.getString(cursor.getColumnIndex("CarPlate")));
                txtAmount.setText("$"+ cursor.getString(cursor.getColumnIndex("Amount")));
                txtLot.setText("Lot :"+ cursor.getString(cursor.getColumnIndex("Lot")));
                txtSpot.setText("Spot :" + cursor.getString(cursor.getColumnIndex("Spot")));
           // }
        } catch (Exception e) {
            Log.e("ReportAdapter", e.getMessage());
        } finally {
            ParkingDB.close();
        }

        return convertView;
    }
}
