package com.example.macstudent.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.provider.ContactsContract;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBName = "ParkingDB";
    public static final String TBName_UserInfo = "UserInfo";
    public static final String TBName_ParkingInfo ="ParkingInfo";

    public static final String NAME ="Name";
    public static final String PHONE="Phone";
    public static final String EMAIL ="Email";
    public static final String PASSWORD ="Password";
    public static final String DoB ="DOB";

    public static final String DATE="date";
    public static final String CARPLATE ="CarPlate";
    public static final String LOT ="Lot";
    public static final String SPOT ="Spot";
    public static final String AMOUNT = "Amount";

    public DBHelper(Context context)
    {
        super(context, DBName,  null, 1);
    }


    public static final String CREATE_TABLE_USER = "CREATE TABLE " + TBName_UserInfo +
            "(Name varchar(100) NOT NULL, Phone varchar(20) NOT NULL," +
            "Email varchar(50) PRIMARY KEY, Password varchar(20) NOT NULL," +
            "DOB varchar(20) NOT NULL)";

    public static final String CREATE_TABLE_PARKING = "CREATE TABLE " + TBName_ParkingInfo +
            "(date varchar(10) NOT NULL, CarPlate varchar(20) NOT NULL," +
            "Lot varchar(10) , Spot varchar(10) NOT NULL," +
            "Amount varchar(20) NOT NULL)";

    @Override
    public void onCreate(SQLiteDatabase db) {
       try {


            Log.v("DBHelper", "Ceating tables");


        db.execSQL(CREATE_TABLE_USER);
        db.execSQL(CREATE_TABLE_PARKING);


      }catch (Exception e){
            Log.e("DBHelper", e.getMessage());
        }
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       try {



           db.execSQL("DROP TABLE IF EXISTS " + TBName_UserInfo);
           db.execSQL("DROP TABLE IF EXISTS " + TBName_ParkingInfo);

    onCreate(db);

       }catch (Exception e){
           Log.e("DBHelper", e.getMessage());
       }
    }

    public boolean addData(String name, String phone, String doB, String email, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();


        contentValues.put(NAME,name);
        contentValues.put(PHONE,phone);
        contentValues.put(DoB,doB);
        contentValues.put(EMAIL,email);
        contentValues.put(PASSWORD,password);

        long result = db.insert(TBName_UserInfo,null,contentValues);

        if (result == -1)
        {
            return false;
        }else {
            return true;
        }

        }


//    public boolean addData1(String date, String lot1 , String spot1 , String amount , String carplate)
//    {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//
//
//        contentValues.put(DATE,date);
//        contentValues.put(LOT,lot1);
//        contentValues.put(SPOT,spot1);
//        contentValues.put(AMOUNT,amount);
//        contentValues.put(CARPLATE,carplate);
//
//        long result = db.insert(TBName_ParkingInfo,null,contentValues);
//
//        if (result == -1)
//        {
//            return false;
//        }else {
//            return true;
//        }
//
//    }

    }

