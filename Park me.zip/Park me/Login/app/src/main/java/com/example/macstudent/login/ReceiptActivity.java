package com.example.macstudent.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ReceiptActivity extends AppCompatActivity implements View.OnClickListener {

    TextView txtDateTime, txtAmount, txtLot, txtSpot, txtCarPlate;
    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;


    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), HomeActivity.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime", "Data Missing"));

        txtCarPlate = findViewById(R.id.txtCarPlate);
        txtCarPlate.setText(sp.getString("CarPlate", "Data Missing"));

        txtLot = findViewById(R.id.txtLot);
        txtLot.setText(sp.getString("Lot", "Data Missing"));

        txtSpot = findViewById(R.id.txtSpot);
        txtSpot.setText(sp.getString("Spot", "Data Missing"));

        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText(String.valueOf(sp.getInt("Amount", 0)));

        dbHelper = new DBHelper(this);
    }


    @Override
    public void onClick(View view) {

        displayData();

}
    private void displayData() {
        try {
            ParkingDB = dbHelper.getReadableDatabase();
            String columns[] = {"Date", "CarPlate", "Lot", "Spot", "Amount"};

            Cursor cursor = ParkingDB.query("ParkingInfo", columns, null,
                    null, null, null, null);

            while (cursor.moveToNext()) {
                String ParkingData = cursor.getString(cursor.getColumnIndex("Date"));
                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("CarPlate"));
                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Lot"));
                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Spot"));
                ParkingData += "\n" + cursor.getString(cursor.getColumnIndex("Amount"));

                Toast.makeText(this, ParkingData, Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            Log.e("ReceiptActivity", e.getMessage());
        } finally {
            ParkingDB.close();
        }
    }
}